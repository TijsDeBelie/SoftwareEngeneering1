import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)

/**
 * Pompoen, het nieuwe spokenvoer
 */
public class Pompoen extends Animal
{

}
